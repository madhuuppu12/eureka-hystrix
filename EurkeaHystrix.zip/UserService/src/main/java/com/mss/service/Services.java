package com.mss.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Component
public class Services {

	@Autowired
	RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "restCallsFall_back")
	public String restCalls(String name) {
		try {
		String response = restTemplate.exchange("http://employee-service/employee/getEmployeeName/{name}",
				HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
				}, name).getBody();
		return response;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return name;
	}

	@SuppressWarnings("unused")
	private String restCallsFall_back(String name) {
		return "CIRCUIT BREAKER ENABLED!!! No Response From Student Service at this moment.Service will be back shortly";

	}

	
}
