package com.mss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class DepartmentApp {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentApp.class, args);
	}

	
}
