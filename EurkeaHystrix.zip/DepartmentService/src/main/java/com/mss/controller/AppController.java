package com.mss.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/department")
public class AppController {

	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/employeeRestCall/{name}")
	private String getDepartment(@PathVariable String name) {

		String response = restTemplate.exchange("http://employee-service/employee/getEmployeeName/{name}",
				HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
				}, name).getBody();

		System.out.println("Response Received as " + response);	
		return "Response ===> " + response;

	}

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
